package com.vanard.faktanyus.ui.profile.edit;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModelProviders;

import com.vanard.faktanyus.R;
import com.vanard.faktanyus.databinding.EditProfileFragmentBinding;
import com.vanard.faktanyus.ui.profile.ProfileFragment;

public class EditProfileFragment extends Fragment {

    private EditProfileViewModel mViewModel;
    private EditProfileFragmentBinding binding;

    public static EditProfileFragment newInstance() {
        return new EditProfileFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(
                inflater, R.layout.edit_profile_fragment, container, false);
        View view = binding.getRoot();
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(EditProfileViewModel.class);
        binding.setViewModel(mViewModel);

        initData();

        binding.backEditProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.replace(R.id.profile_container, ProfileFragment.newInstance()).addToBackStack(null);
                ft.commit();
            }
        });
    }

    private void initData() {
        mViewModel.email.setValue("");
        mViewModel.fullname.setValue("");
        mViewModel.username.setValue("");
        mViewModel.oldPassword.setValue("");
        mViewModel.password.setValue("");
        mViewModel.repassword.setValue("");
        mViewModel.phone.setValue("");
    }

}
