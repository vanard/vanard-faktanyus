package com.vanard.faktanyus.ui.main.year;

import androidx.lifecycle.ViewModel;

public class YearFactViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
