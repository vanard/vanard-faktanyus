package com.vanard.faktanyus.ui.main.date;

import androidx.lifecycle.ViewModel;

public class DateDescriptionViewModel extends ViewModel {
}
