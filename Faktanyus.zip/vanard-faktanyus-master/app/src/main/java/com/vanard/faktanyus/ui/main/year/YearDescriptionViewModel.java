package com.vanard.faktanyus.ui.main.year;

import androidx.lifecycle.ViewModel;

public class YearDescriptionViewModel extends ViewModel {
}
