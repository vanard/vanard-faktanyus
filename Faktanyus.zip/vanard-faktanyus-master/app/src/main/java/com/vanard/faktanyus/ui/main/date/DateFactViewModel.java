package com.vanard.faktanyus.ui.main.date;

import androidx.lifecycle.ViewModel;

public class DateFactViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
