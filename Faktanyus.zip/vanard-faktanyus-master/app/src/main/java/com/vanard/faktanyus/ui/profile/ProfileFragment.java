package com.vanard.faktanyus.ui.profile;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModelProviders;

import com.vanard.faktanyus.R;
import com.vanard.faktanyus.databinding.ProfileFragmentBinding;
import com.vanard.faktanyus.ui.profile.edit.EditProfileFragment;

public class ProfileFragment extends Fragment {

    private ProfileViewModel mViewModel;
    private ProfileFragmentBinding binding;

    public static ProfileFragment newInstance() {
        return new ProfileFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(
                inflater, R.layout.profile_fragment, container, false);
        View view = binding.getRoot();
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(ProfileViewModel.class);

        binding.setViewModel(mViewModel);

        initData();

        binding.editProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.add(R.id.profile_container, EditProfileFragment.newInstance());
                ft.commit();
            }
        });

        binding.backProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requireActivity().finish();
            }
        });
    }

    private void initData() {
        mViewModel.email.setValue("");
        mViewModel.fullname.setValue("");
        mViewModel.username.setValue("");
        mViewModel.password.setValue("");
        mViewModel.repassword.setValue("");
        mViewModel.phone.setValue("");
    }



}
