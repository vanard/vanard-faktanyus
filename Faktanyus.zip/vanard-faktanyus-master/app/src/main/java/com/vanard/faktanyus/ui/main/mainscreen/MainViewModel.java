package com.vanard.faktanyus.ui.main.mainscreen;

import androidx.lifecycle.ViewModel;

public class MainViewModel extends ViewModel {
    //
}
